﻿using DBAccess;
using EmployeeWCFServic;
using Models;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace EmployeeWCFServic
{
    [ServiceBehavior(InstanceContextMode =InstanceContextMode.PerCall)]
    public class EmployeesService : IEmployeesService
    {
        public string GetProduct(string prod)
        {
            try
            {
                return "Hello " + prod;
            }
            catch (Exception ex)
            {

                throw new FaultException(ex.Message + ex.InnerException);
            }
           
        }

        public List<Employee> GetAllEmployes()
        {
            List<Employee> employes = null;
            try
            {
                 employes = EmployeeSQL.GetAllEmployes();
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message + ex.InnerException);
            }
           
            return employes;
        }

        public List<Employee> GetEmployesById(int id)
        {
            List<Employee> employes = null;
            try
            {
                 employes = EmployeeSQL.GetEmployesById(id);
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message + ex.InnerException);
            }
          
            return employes;
        }
    }
}
