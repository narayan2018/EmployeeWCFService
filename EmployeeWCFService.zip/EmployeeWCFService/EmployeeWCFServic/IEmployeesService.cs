﻿using Models;
using System.Collections.Generic;
using System.ServiceModel;

namespace EmployeeWCFServic
{
    [ServiceContract(Namespace = "http://PragimTech.com/ServiceVersion1")]
    public interface IEmployeesService
    {
        [OperationContract]
        string GetProduct(string prod);

        [OperationContract]
        List<Employee> GetAllEmployes();

        [OperationContract]
        List<Employee> GetEmployesById(int id);
    }
}
