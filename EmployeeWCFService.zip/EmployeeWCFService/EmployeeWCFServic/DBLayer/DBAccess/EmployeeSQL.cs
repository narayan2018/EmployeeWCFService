﻿using Models;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace DBAccess
{
    public class EmployeeSQL
    {
        public static List<Employee> GetAllEmployes()
        {
            List<Employee> employes = new List<Employee>();
            string conStr = "Data Source = DESKTOP-KH43EP4; Initial Catalog = Company; " + "Integrated Security=true;";
            using (SqlConnection con = new SqlConnection(conStr))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from Employee", con))
                {
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        Employee emp = new Employee();
                        emp.empid = dr.GetInt32(0);
                        emp.first_name = dr.GetString(1);
                        emp.last_name = dr.GetString(2);
                        emp.email = dr.GetString(3);
                        emp.phone = dr.GetString(4);
                        emp.salary = dr.GetInt32(5);
                        emp.managerid = dr.GetInt32(6);
                        employes.Add(emp);
                    }
                }
            }
            return employes;
        }

        public static List<Employee> GetEmployesById(int id)
        {
            List<Employee> employes = new List<Employee>();
            string conStr = "Data Source = DESKTOP-KH43EP4; Initial Catalog = Company; " + "Integrated Security=true;";
            using (SqlConnection con = new SqlConnection(conStr))
            {
                using (SqlCommand cmd = new SqlCommand("Select * from Employee where employee_id=" + id, con))
                {
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        Employee emp = new Employee();
                        emp.empid = dr.GetInt32(0);
                        emp.first_name = dr.GetString(1);
                        emp.last_name = dr.GetString(2);
                        emp.email = dr.GetString(3);
                        emp.phone = dr.GetString(4);
                        emp.salary = dr.GetInt32(5);
                        emp.managerid = dr.GetInt32(6);
                        employes.Add(emp);
                    }
                }
            }
            return employes;
        }
    }
}
