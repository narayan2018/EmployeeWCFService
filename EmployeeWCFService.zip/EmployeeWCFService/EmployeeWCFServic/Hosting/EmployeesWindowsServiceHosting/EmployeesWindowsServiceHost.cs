﻿using System.ServiceModel;
using System.ServiceProcess;

namespace ProductWindowsServiceHost
{
    public partial class WindowsServiceHost : ServiceBase
    {
        ServiceHost serviceHost;
        public WindowsServiceHost()
        {
            InitializeComponent();
            ServiceName = "EmployeeWindowsService";

        }

        protected override void OnStart(string[] args)
        {
            if (serviceHost != null)
            {
                serviceHost.Close();
            }

            // Create a ServiceHost for the CalculatorService type and
            // provide the base address.
            serviceHost = new ServiceHost(typeof(EmployeeWCFServic.EmployeesService));

            // Open the ServiceHostBase to create listeners and start
            // listening for messages.
            serviceHost.Open();
        }

        protected override void OnStop()
        {
            if (serviceHost != null)
            {
                serviceHost.Close();
                serviceHost = null;
            }
        }
    }
}
