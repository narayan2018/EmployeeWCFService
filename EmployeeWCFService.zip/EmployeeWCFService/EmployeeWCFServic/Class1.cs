﻿namespace EmployeeWCFServic
{
    public class Class1
    {
    }   
}
 